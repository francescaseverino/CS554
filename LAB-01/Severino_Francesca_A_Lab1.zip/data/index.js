module.exports = {
    users: require("./users"),
    recipes: require("./recipes"),
    reviews: require("./reviews")
}